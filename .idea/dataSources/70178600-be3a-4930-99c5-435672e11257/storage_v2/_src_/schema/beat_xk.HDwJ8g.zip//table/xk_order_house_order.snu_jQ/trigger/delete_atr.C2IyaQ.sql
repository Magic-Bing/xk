CREATE TRIGGER delete_atr
AFTER DELETE ON xk_order_house_order
FOR EACH ROW
  BEGIN
delete from xk_trade where yw_id=old.id and source='微信认购'  and status='选房';
END;
