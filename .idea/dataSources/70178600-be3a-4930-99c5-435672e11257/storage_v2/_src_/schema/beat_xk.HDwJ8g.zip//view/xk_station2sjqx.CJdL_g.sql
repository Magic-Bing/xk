CREATE VIEW xk_station2sjqx AS
  SELECT
    `a`.`id`         AS `id`,
    `a`.`station_id` AS `station_id`,
    `a`.`pc_id`      AS `pc_id`,
    `a`.`proj_id`    AS `proj_id`,
    `d`.`cp_id`      AS `cp_id`,
    `c`.`is_yx`      AS `is_yx`,
    `c`.`is_dq`      AS `is_dq`,
    `c`.`ledurl`     AS `ledurl`,
    `c`.`name`       AS `pcname`,
    `d`.`name`       AS `projname`
  FROM ((`beat_xk`.`xk_station2pc` `a` LEFT JOIN `beat_xk`.`xk_kppc` `c` ON ((`a`.`pc_id` = `c`.`id`))) LEFT JOIN
    `beat_xk`.`xk_project` `d` ON ((`a`.`proj_id` = `d`.`id`)));
