CREATE VIEW xk_buildlist AS
  SELECT
    `a`.`id`        AS `id`,
    `a`.`pc_id`     AS `pc_id`,
    `a`.`proj_id`   AS `proj_id`,
    `a`.`buildname` AS `buildname`,
    `a`.`buildcode` AS `buildcode`
  FROM (`beat_xk`.`xk_build` `a` LEFT JOIN `beat_xk`.`xk_kppc` `b` ON ((`a`.`pc_id` = `b`.`id`)))
  WHERE (`b`.`is_yx` = 1);
