CREATE VIEW xk_cst2roomslist AS
  SELECT
    `a`.`id`      AS `id`,
    `a`.`cst_id`  AS `cst_id`,
    `a`.`room_id` AS `room_id`,
    `a`.`sctime`  AS `sctime`,
    `b`.`proj_id` AS `proj_id`,
    `b`.`pc_id`   AS `pc_id`,
    `b`.`is_dq`   AS `is_dq`,
    `b`.`is_xf`   AS `is_xf`
  FROM (`beat_xk`.`xk_cst2rooms` `a` LEFT JOIN `beat_xk`.`xk_roomlist` `b` ON ((`a`.`room_id` = `b`.`id`)));
