CREATE TRIGGER project_insert
AFTER INSERT ON xk_project
FOR EACH ROW
  BEGIN
     insert into xk_station(cp_id,proj_id,name) values(new.cp_id,new.id,'销售管理');
     insert into xk_station(cp_id,proj_id,name) values(new.cp_id,new.id,'置业顾问');
     insert into xk_station(cp_id,proj_id,name) values(new.cp_id,new.id,'LED 展示');
END;
