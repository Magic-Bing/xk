CREATE TRIGGER conpany_insert
AFTER INSERT ON xk_company
FOR EACH ROW
  BEGIN
     insert into xk_station(cp_id,name) values(new.id,'公司管理员');
END;
