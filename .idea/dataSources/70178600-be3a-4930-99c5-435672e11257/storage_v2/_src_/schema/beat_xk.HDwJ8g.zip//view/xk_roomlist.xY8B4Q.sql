CREATE VIEW xk_roomlist AS
  SELECT
    `a`.`id`             AS `id`,
    `a`.`discount`       AS `discount`,
    `a`.`bld_id`         AS `bld_id`,
    `b`.`pc_id`          AS `pc_id`,
    `a`.`ycx_price`      AS `ycx_price`,
    `a`.`fq_price`       AS `fq_price`,
    `a`.`aj_price`       AS `aj_price`,
    `a`.`gjj_price`      AS `gjj_price`,
    `a`.`proj_id`        AS `proj_id`,
    `a`.`cp_id`          AS `cp_id`,
    `a`.`unit`           AS `unit`,
    `a`.`floor`          AS `floor`,
    `a`.`no`             AS `no`,
    `a`.`room`           AS `room`,
    `a`.`hx`             AS `hx`,
    `a`.`area`           AS `area`,
    `a`.`tnarea`         AS `tnarea`,
    `a`.`price`          AS `price`,
    `a`.`tnprice`        AS `tnprice`,
    `a`.`total`          AS `total`,
    `a`.`is_xf`          AS `is_xf`,
    `a`.`cstid`          AS `cstid`,
    `a`.`xftime`         AS `xftime`,
    `a`.`xstype`         AS `xstype`,
    `f`.`customer_name`  AS `cstname`,
    `f`.`customer_phone` AS `phone`,
    `f`.`cyjno`          AS `cyjno`,
    `f`.`cardno`         AS `cardno`,
    `a`.`is_qxxf`        AS `is_qxxf`,
    `a`.`qxxftime`       AS `qxxftime`,
    `b`.`buildname`      AS `buildname`,
    `b`.`buildcode`      AS `buildcode`,
    `c`.`name`           AS `pcname`,
    `c`.`is_dq`          AS `is_dq`,
    `d`.`name`           AS `projname`,
    `e`.`name`           AS `cpname`
  FROM (((((`beat_xk`.`xk_room` `a` LEFT JOIN `beat_xk`.`xk_build` `b` ON ((`a`.`bld_id` = `b`.`id`))) LEFT JOIN
    `beat_xk`.`xk_kppc` `c` ON ((`b`.`pc_id` = `c`.`id`))) LEFT JOIN `beat_xk`.`xk_project` `d`
      ON ((`a`.`proj_id` = `d`.`id`))) LEFT JOIN `beat_xk`.`xk_company` `e` ON ((`a`.`cp_id` = `e`.`id`))) LEFT JOIN
    `beat_xk`.`xk_choose` `f` ON ((`a`.`cstid` = `f`.`id`)))
  WHERE (`d`.`status` = 1);
