CREATE TRIGGER insert_atr
AFTER INSERT ON xk_order_house_order
FOR EACH ROW
  BEGIN
insert into xk_trade(yw_id,room_id,cst_id,source,status,isyx,tradetime,code,ywy)
values (new.id,new.room_id,new.belong_uid,'微信认购','选房',1,new.log_time,new.code,'');
END;
